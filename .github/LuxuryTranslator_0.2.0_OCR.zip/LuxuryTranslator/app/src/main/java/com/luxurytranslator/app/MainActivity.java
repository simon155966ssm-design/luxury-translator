package com.luxurytranslator.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.net.Uri;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 701;
    private TextView statusText, resultText;
    private Button toggleButton;
    private boolean overlayRunning = false;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextRecognizer recognizer;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        statusText = findViewById(R.id.statusText);
        resultText = findViewById(R.id.resultText);
        Button permissionButton = findViewById(R.id.permissionButton);
        toggleButton = findViewById(R.id.toggleButton);
        Button scanButton = findViewById(R.id.scanButton);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        permissionButton.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else updateStatus();
        });
        toggleButton.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                statusText.setText("ابتدا مجوز پنجره شناور را فعال کنید."); return;
            }
            Intent serviceIntent = new Intent(this, FloatingTranslatorService.class);
            if (!overlayRunning) {
                startService(serviceIntent); overlayRunning = true;
                toggleButton.setText("خاموش‌کردن مترجم شناور");
                statusText.setText("دکمه شناور فعال شد. آن را لمس کنید تا تشخیص متن آغاز شود.");
            } else {
                stopService(serviceIntent); overlayRunning = false;
                toggleButton.setText("فعال‌کردن مترجم شناور");
                statusText.setText("مترجم شناور خاموش شد.");
            }
        });
        scanButton.setOnClickListener(v -> requestScreenCapture());
        if (getIntent() != null && "SCAN_SCREEN".equals(getIntent().getAction())) requestScreenCapture();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && "SCAN_SCREEN".equals(intent.getAction())) requestScreenCapture();
    }

    private void requestScreenCapture() {
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                mediaProjection = manager.getMediaProjection(resultCode, data);
                statusText.setText("اجازه ثبت شد. حالا به برنامه یا صفحه موردنظر برو؛ سه ثانیه دیگر تصویر گرفته می‌شود.");
                handler.postDelayed(this::captureOneFrame, 3000);
            } else statusText.setText("مجوز ثبت تصویر صفحه داده نشد.");
        }
    }

    private void captureOneFrame() {
        if (mediaProjection == null) return;
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 30) metrics = getResources().getDisplayMetrics();
        else wm.getDefaultDisplay().getRealMetrics(metrics);
        int width = metrics.widthPixels, height = metrics.heightPixels, density = metrics.densityDpi;
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay("LuxuryTranslatorCapture", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, handler);
        imageReader.setOnImageAvailableListener(reader -> {
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image == null) return;
                Image.Plane plane = image.getPlanes()[0];
                ByteBuffer buffer = plane.getBuffer();
                int pixelStride = plane.getPixelStride(), rowStride = plane.getRowStride();
                int rowPadding = rowStride - pixelStride * width;
                Bitmap padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
                padded.copyPixelsFromBuffer(buffer);
                Bitmap bitmap = Bitmap.createBitmap(padded, 0, 0, width, height);
                padded.recycle();
                runOcr(bitmap);
            } catch (Exception e) {
                statusText.setText("خطا در گرفتن تصویر صفحه: " + e.getMessage());
            } finally { if (image != null) image.close(); releaseCapture(); }
        }, handler);
    }

    private void runOcr(Bitmap bitmap) {
        statusText.setText("در حال تشخیص نوشته‌های صفحه...");
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener(result -> {
                StringBuilder out = new StringBuilder();
                for (Text.TextBlock block : result.getTextBlocks()) out.append(block.getText()).append("\\n\\n");
                String found = out.toString().trim();
                resultText.setText(found.isEmpty() ? "متنی در تصویر پیدا نشد." : found);
                statusText.setText("تشخیص متن تمام شد. این نسخه متن را استخراج می‌کند و هنوز ترجمه نمی‌کند.");
            })
            .addOnFailureListener(e -> statusText.setText("تشخیص متن ناموفق بود: " + e.getMessage()))
            .addOnCompleteListener(task -> bitmap.recycle());
    }

    private void releaseCapture() {
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (imageReader != null) { imageReader.close(); imageReader = null; }
        if (mediaProjection != null) { mediaProjection.stop(); mediaProjection = null; }
    }

    @Override protected void onResume() { super.onResume(); updateStatus(); }
    private void updateStatus() {
        if (statusText == null) return;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))
            statusText.setText("مجوز پنجره شناور فعال است. می‌توانید دکمه مترجم را روشن کنید.");
        else statusText.setText("مجوز پنجره شناور هنوز فعال نشده است.");
    }
    @Override protected void onDestroy() {
        releaseCapture();
        if (recognizer != null) recognizer.close();
        super.onDestroy();
    }
}
